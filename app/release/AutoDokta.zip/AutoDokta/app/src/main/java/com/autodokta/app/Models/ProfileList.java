package com.autodokta.app.Models;

public class ProfileList {

    private String title;

    public ProfileList(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
