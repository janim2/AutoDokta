package com.autodokta.app.Models;

public class UpdateModel {

    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
